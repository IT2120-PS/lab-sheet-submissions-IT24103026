setwd("C:\\Users\\IT24103026\\Desktop\\IT24103026")

# Create a vector with the observed number of purchases for each snack type
observed_counts <- c(A = 120, B = 95, C = 85, D = 100)

# Perform the Chi-squared
chisq.test(observed_counts)

# the p-value is not less than 0.05, we do not reject the null hypothesis.
# There is not enough statistical evidence to reject the vending machine owner's 
# claim that customers choose the four snack types with equal probability.

